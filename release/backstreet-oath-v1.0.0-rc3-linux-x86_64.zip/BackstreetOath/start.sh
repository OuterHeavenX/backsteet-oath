#!/bin/sh
# Backstreet Oath launcher. Works from any folder, including paths with spaces.
HERE="$(CDPATH= cd -- "$(dirname -- "$0")" && pwd)"
cd "$HERE" || exit 1
chmod +x "./BackstreetOath.x86_64" 2>/dev/null
exec "./BackstreetOath.x86_64" "$@"
