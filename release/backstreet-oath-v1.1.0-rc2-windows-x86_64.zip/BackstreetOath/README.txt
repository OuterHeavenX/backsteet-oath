BACKSTREET OATH 1.1.0-rc2
An original belt-scrolling action RPG. Made with Godot 4.7.2.

Linux / Steam Deck: run ./start.sh (or BackstreetOath.x86_64). See STEAM_DECK.md.
Windows: run BackstreetOath.exe.
Controls: see CONTROLS.md (rebindable in-game).
Saves: Linux ~/.local/share/godot/app_userdata/Backstreet Oath/ ; Windows %APPDATA%\Godot\app_userdata\Backstreet Oath\
